/** Automatically generated file. DO NOT MODIFY */
package com.eoe.elts;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}