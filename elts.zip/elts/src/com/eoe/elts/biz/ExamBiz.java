package com.eoe.elts.biz;

import java.io.Serializable;
import java.util.ArrayList;

import com.eoe.elts.entity.ExamInfo;
import com.eoe.elts.entity.Question;
import com.eoe.elts.entity.User;

public class ExamBiz implements IExamBiz,Serializable {

	@Override
	public void login(int uid, String pwd) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void loadQuestions() {
		// TODO Auto-generated method stub

	}

	@Override
	public ExamInfo beginExam() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Question getQuestion(int qid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveUserAnswers(int qid, ArrayList<String> userAnswers) {
		// TODO Auto-generated method stub

	}

	@Override
	public int over() {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public User getUser() {
		// TODO Auto-generated method stub
		return null;
	}

}
