package com.eoe.pre.day01;

public class Test03 {
	public static void main(String[] args) {
		System.out.println("hello Android");
	}
}
