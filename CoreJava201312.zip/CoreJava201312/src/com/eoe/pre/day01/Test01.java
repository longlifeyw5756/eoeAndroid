package com.eoe.pre.day01;

public class Test01 {
	public static void main(String[] args) {
		System.out.println("Hello eoe!");
	}
}
