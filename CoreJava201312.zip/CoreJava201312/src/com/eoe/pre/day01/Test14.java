package com.eoe.pre.day01;

public class Test14 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i=97;//'a'��unicode
		do{
			System.out.println((char)i+":"+i);
			i++;
		}while(i<=122);
	}

}
