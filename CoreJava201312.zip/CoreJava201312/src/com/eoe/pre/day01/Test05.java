package com.eoe.pre.day01;

public class Test05 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		byte b=15;// -128-127
		double kb=Math.pow(2, 10);
		System.out.println("1kb="+Math.pow(2, 10)+"byte");
		System.out.println("1Mb="+Math.pow(2, 20)+"�ֽ�");
		System.out.println("1GB="+Math.pow(2, 31)+"�ֽ�");
		System.out.println("1TB="+Math.pow(2, 40)+"�ֽ�");
		int a=125;//4byte�Ĵ洢�ռ�
		long c=1000;//8byte�Ĵ洢�ռ�
		c=2200000000l;
	}

}
