package com.eoe.pre.day01;

public class Test19 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i=1;
		while(true){
			System.out.println("�������Գ�"+i+"��");
			i++;
		}
	}

}
