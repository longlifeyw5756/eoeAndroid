package com.eoe.pre.day01;

public class Test15 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		char c='a';
		do{
			System.out.println(c+":"+(int)c);
			c++;
		}while(c<='z');
	}

}
