package com.eoe.pre.day03;

public class Test01 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person p=new Person("�ŷ�", '��', 33, 1.99, "���ŵ�");
		p.say();
	}

}
