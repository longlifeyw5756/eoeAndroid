package com.eoe.pre.day03.action;

public class Test07 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Car car=new Car();
		car.run();
		Computer pc=new Computer();
		pc.run();
		Company com=new Company();
		com.run();
		Player player=new Player();
		player.run();
	}

}
