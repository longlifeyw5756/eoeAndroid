package com.eoe.pre.day03.action;

public interface Action {
	public static final String COMPUTER="�����";
	public static final String COMPANY="��˾";
	public static final String PLAYER="�˶�Ա";
	public static final String CAR="����";
	
	void run();
}
