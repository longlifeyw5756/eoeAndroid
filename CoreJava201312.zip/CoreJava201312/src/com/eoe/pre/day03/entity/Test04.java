package com.eoe.pre.day03.entity;

public class Test04 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person_ p=new Person_();
		p.setName("�ŷ�");
		p.setSex('a');
		p.setAge(-100);
		p.say();
		
	}

}
