package com.eoe.pre.day03;


public class Test03 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person p1=new Person("�ŷ�", '��', 33, 1.99, "���ŵ�");
		Person p2=p1;
		
	}

}
