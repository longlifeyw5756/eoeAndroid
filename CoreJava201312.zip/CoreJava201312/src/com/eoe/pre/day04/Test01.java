package com.eoe.pre.day04;

public class Test01 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//System.out.println(5/0);
//		int[] a={3,1,5};
//		System.out.println(a[3]);
		String s="a";
		Object o=s;
		Integer i=(Integer) o;
	}

}
