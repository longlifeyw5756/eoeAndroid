package com.eoe.pre.day02;

public class Test01 {

	/**
	 * null:��ַΪ��
	 */
	public static void main(String[] args) {
		int[] scores=new int[5];
		scores[0]=95;
		scores[1]=86;
		scores[2]=73;
		scores[3]=55;
		scores[4]=60;
		
		for(int i=0;i<5;i++){
			System.out.println(scores[i]);
		}
		
	}

}
