
public class Test02 {
	public static void main(String[] args) {
		System.out.println("hello java");
	}
}
